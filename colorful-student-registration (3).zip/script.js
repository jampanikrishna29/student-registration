const form=document.getElementById('studentForm');
const list=document.getElementById('studentList');
form.addEventListener('submit',e=>{
e.preventDefault();
const n=name.value.trim(), em=email.value.trim(), c=course.value.trim();
const tr=document.createElement('tr');
tr.innerHTML=`<td>${n}</td><td>${em}</td><td>${c}</td><td><button class="delete" onclick="this.closest('tr').remove()">Delete</button></td>`;
list.appendChild(tr);
form.reset();
});
